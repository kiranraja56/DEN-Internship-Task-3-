package com.example.mytask;


import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.mytask.R;
import com.example.mytask.Viewmodel.TaskViewModel;
import com.example.mytask.model.Task;

public class AddEditTaskActivity extends AppCompatActivity {

    private EditText editTitle, editDescription, editDate;
    private Spinner spinnerPriority;
    private Button btnSave;

    private TaskViewModel taskViewModel;
    private int taskId = -1;
    private boolean isEdit = false;
    private boolean completed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_task);

        editTitle = findViewById(R.id.edit_title);
        editDescription = findViewById(R.id.edit_description);
        editDate = findViewById(R.id.edit_date);
        spinnerPriority = findViewById(R.id.spinner_priority);
        btnSave = findViewById(R.id.btn_save);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.priority_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPriority.setAdapter(adapter);

        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);

        if (getIntent().hasExtra("task_id")) {
            isEdit = true;
            taskId = getIntent().getIntExtra("task_id", -1);
            editTitle.setText(getIntent().getStringExtra("title"));
            editDescription.setText(getIntent().getStringExtra("description"));
            editDate.setText(getIntent().getStringExtra("date"));
            spinnerPriority.setSelection(adapter.getPosition(getIntent().getStringExtra("priority")));
            completed = getIntent().getBooleanExtra("completed", false);
        }

        btnSave.setOnClickListener(v -> {
            String title = editTitle.getText().toString();
            String description = editDescription.getText().toString();
            String date = editDate.getText().toString();
            String priority = spinnerPriority.getSelectedItem().toString();

            if (TextUtils.isEmpty(title)) {
                editTitle.setError("Title required");
                return;
            }

            Task task = new Task(title, description, date, priority, completed);

            if (isEdit) {
                task.setId(taskId);
                taskViewModel.update(task);
            } else {
                taskViewModel.insert(task);
            }

            finish();
        });
    }
}
