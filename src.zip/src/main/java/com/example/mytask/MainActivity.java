package com.example.mytask;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mytask.Adapter.TaskAdapter;
import com.example.mytask.model.Task;
import com.example.mytask.Viewmodel.TaskViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private Button btnLogout;
    private RecyclerView recyclerView;
    private FloatingActionButton fabAdd;

    private DatabaseReference usersRef;
    private FirebaseAuth mAuth;

    private TaskAdapter taskAdapter;
    private TaskViewModel taskViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        usersRef = FirebaseDatabase.getInstance().getReference("Users");

        tvWelcome = findViewById(R.id.tvWelcome);
        btnLogout = findViewById(R.id.btnLogout);
        recyclerView = findViewById(R.id.recycler_view);
        fabAdd = findViewById(R.id.fab_add);

        if (mAuth.getCurrentUser() == null) {
            startActivity(new Intent(this, loginactivity.class));
            finish();
        } else {
            String uid = mAuth.getCurrentUser().getUid();
            usersRef.child(uid).get().addOnSuccessListener(snapshot -> {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    tvWelcome.setText("Welcome, " + name + "!");
                }
            });
        }

        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            startActivity(new Intent(MainActivity.this, loginactivity.class));
            finish();
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskAdapter = new TaskAdapter(new TaskAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(Task task) {
                Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
                intent.putExtra("task_id", task.getId());
                intent.putExtra("title", task.getTitle());
                intent.putExtra("description", task.getDescription());
                intent.putExtra("date", task.getDate());
                intent.putExtra("priority", task.getPriority());
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(Task task) {
                taskViewModel.delete(task);
            }

            @Override
            public void onStatusToggle(Task task) {
                task.setCompleted(!task.isCompleted());
                taskViewModel.update(task);
            }
        });

        recyclerView.setAdapter(taskAdapter);

        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);
        taskViewModel.getAllTasks().observe(this, tasks -> taskAdapter.setTasks(tasks));

        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
            startActivity(intent);
        });
    }
}
