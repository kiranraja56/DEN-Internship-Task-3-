package com.example.mytask;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mytask.MainActivity;
import com.example.mytask.loginactivity;
import com.google.firebase.auth.FirebaseAuth;

public class splashactivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            // User is logged in → Go to MainActivity
            startActivity(new Intent(splashactivity.this, MainActivity.class));
        } else {
            // No user → Go to LoginActivity
            startActivity(new Intent(splashactivity.this, loginactivity.class));
        }
        finish();
    }
}
